if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part1");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 50, 190);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);


if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part2");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 50, 190);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);



if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part3");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 20, 60);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);


if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part4");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 20, 40);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);


if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part5");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 20, 60);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);



if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part6");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 20, 60);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);



if(Modernizr.canvas){
    //Canvas is supported

    var theCanvas = document.getElementById("Part7");
    var ctx = theCanvas.getContext("2d");


    //Draw some text on our canvas
    ctx.font = "25pt Georgia";
    ctx.fillText("Canvas is supported!", 350, 60);


}else {
    //Canvas is not supported
    //Polyfill would go here


}

console.log(Modernizr);







